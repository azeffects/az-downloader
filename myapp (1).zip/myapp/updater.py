"""Update checker: compares PIPELINE_VERSION with the latest GitHub release.

Default repo is a placeholder; the user sets their real repo in Settings
(saved to data/repo.json) which overrides REPO.
"""
import json
import os
import urllib.request

from pipeline import PIPELINE_VERSION

REPO = "YOUR_GITHUB_USERNAME/az-downloader"  # overridden by data/repo.json
TIMEOUT = 15


def data_dir():
    base = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    d = os.path.join(base, "AZ Downloader", "data")
    os.makedirs(d, exist_ok=True)
    return d


def get_repo():
    try:
        p = os.path.join(data_dir(), "repo.json")
        if os.path.exists(p):
            with open(p) as f:
                r = json.load(f).get("repo", "").strip()
                if r:
                    return r
    except Exception:
        pass
    return REPO


def set_repo(repo):
    p = os.path.join(data_dir(), "repo.json")
    with open(p, "w") as f:
        json.dump({"repo": repo.strip()}, f)


def _ver_tuple(v):
    v = v.strip().lstrip("vV")
    parts = []
    for x in v.split("."):
        try:
            parts.append(int(x))
        except ValueError:
            parts.append(0)
    return tuple(parts)


def check():
    """Return dict: update_available, latest, url, current, error."""
    repo = get_repo()
    if "YOUR_GITHUB_USERNAME" in repo:
        return {"update_available": False, "latest": None, "url": None,
                "current": PIPELINE_VERSION,
                "error": "Set your GitHub repo in Settings first."}
    api = "https://api.github.com/repos/%s/releases/latest" % repo
    try:
        req = urllib.request.Request(api, headers={"User-Agent": "AZDownloader"})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            rel = json.load(r)
        tag = (rel.get("tag_name") or "").strip()
        if not tag:
            return {"update_available": False, "latest": None, "url": None,
                    "current": PIPELINE_VERSION, "error": "No releases found."}
        asset_url = None
        for a in rel.get("assets", []):
            name = a.get("name", "")
            if name.lower().endswith(".exe"):
                asset_url = a.get("browser_download_url")
                break
        newer = _ver_tuple(tag) > _ver_tuple(PIPELINE_VERSION)
        return {"update_available": newer, "latest": tag.lstrip("vV"),
                "url": asset_url, "current": PIPELINE_VERSION, "error": None}
    except Exception as e:
        return {"update_available": False, "latest": None, "url": None,
                "current": PIPELINE_VERSION, "error": str(e)}


def download(url, dest, progress_cb=None):
    """Stream-download a file with optional progress callback(bytes_done, total)."""
    req = urllib.request.Request(url, headers={"User-Agent": "AZDownloader"})
    with urllib.request.urlopen(req, timeout=60) as r:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        with open(dest, "wb") as f:
            while True:
                chunk = r.read(1024 * 256)
                if not chunk:
                    break
                f.write(chunk)
                done += len(chunk)
                if progress_cb:
                    progress_cb(done, total)
    return dest
