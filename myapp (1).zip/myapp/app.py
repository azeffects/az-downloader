"""AZ Downloader PC v1.0 - Flask backend + multi-thread download engine.

Download engine is stdlib-only (urllib + threading):
- 4 worker threads with HTTP Range requests, resume via .part files
- Single-thread fallback when the server ignores Range
- queue.json persists jobs across restarts (incomplete -> paused)
"""
import hashlib
import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request
from collections import deque
from pathlib import Path

from flask import Flask, jsonify, request, send_file

import updater
from pipeline import APP_NAME, PIPELINE_VERSION

app = Flask(__name__, static_folder="static", static_url_path="/static")

CHUNK = 1024 * 256
NTHREADS = 4
UA = {"User-Agent": "AZDownloader/1.0"}


# ---------------------------------------------------------------- paths
def download_dir():
    override = os.environ.get("AZDL_DOWNLOAD_DIR")
    if override:
        d = Path(override)
    else:
        d = Path.home() / "Downloads" / "AZDownloader"
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception:
            d = Path("downloads")
    d.mkdir(parents=True, exist_ok=True)
    return d


def queue_path():
    return Path(updater.data_dir()) / "queue.json"


def sanitize_filename(name):
    name = (name or "").strip().replace("\\", "_").replace("/", "_")
    name = re.sub(r'[<>:"|?*\x00-\x1f]', "_", name).strip(" .")
    return name[:180] or "download"


def filename_from_url(url, headers=None):
    if headers:
        cd = headers.get("Content-Disposition") or ""
        m = re.search(r'filename\*?=(?:UTF-8\'\')?"?([^";]+)"?', cd)
        if m:
            return sanitize_filename(urllib.parse.unquote(m.group(1)))
    path = urllib.parse.urlparse(url).path.rstrip("/")
    base = os.path.basename(path)
    if base and "." in base:
        return sanitize_filename(urllib.parse.unquote(base))
    return "download.bin"


def probe(url):
    """HEAD (fallback: ranged GET) -> (size or None, range_supported bool, headers)."""
    size, ranged, headers = None, False, {}
    try:
        req = urllib.request.Request(url, headers=UA, method="HEAD")
        with urllib.request.urlopen(req, timeout=15) as r:
            headers = dict(r.headers)
            cl = r.headers.get("Content-Length")
            if cl and cl.isdigit():
                size = int(cl)
            ar = (r.headers.get("Accept-Ranges") or "").lower()
            if ar == "bytes":
                ranged = True
    except Exception:
        pass
    if size is None or not ranged:
        # Try a 1-byte ranged GET: proves Range support and reveals total size.
        try:
            req = urllib.request.Request(url, headers={**UA, "Range": "bytes=0-0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                headers = dict(r.headers)
                if r.status == 206:
                    ranged = True
                    cr = r.headers.get("Content-Range") or ""
                    m = re.search(r"/(\d+)", cr)
                    if m:
                        size = int(m.group(1))
                else:
                    cl = r.headers.get("Content-Length")
                    if cl and cl.isdigit() and size is None:
                        size = int(cl)
        except Exception:
            pass
    return size, ranged, headers


# ---------------------------------------------------------------- jobs
class Job:
    def __init__(self, jid, url, filename, size, ranged):
        self.id = jid
        self.url = url
        self.filename = filename
        self.size = size            # None if unknown
        self.ranged = ranged
        self.status = "queued"      # queued/downloading/paused/completed/error/cancelled
        self.downloaded = 0
        self.error = ""
        self.created = int(time.time())
        self.pause_flag = False
        self.stop_flag = False
        self.lock = threading.Lock()
        self.samples = deque()      # (timestamp, bytes) for speed
        self.threads = []
        self.range_retried = False  # one automatic fallback to single-thread

    def to_dict(self):
        return {
            "id": self.id, "url": self.url, "filename": self.filename,
            "size": self.size, "status": self.status,
            "downloaded": self.downloaded, "speed": self.speed(),
            "error": self.error, "created": self.created,
        }

    def speed(self):
        now = time.time()
        while self.samples and now - self.samples[0][0] > 5:
            self.samples.popleft()
        if not self.samples:
            return 0
        total = sum(b for _, b in self.samples)
        span = now - self.samples[0][0]
        return int(total / span) if span > 0.05 else 0

    def add_bytes(self, n):
        with self.lock:
            self.downloaded += n
            self.samples.append((time.time(), n))

    def part_path(self, i):
        return download_dir() / (self.filename + ".p%d" % i)

    def single_part_path(self):
        return download_dir() / (self.filename + ".part")

    def final_path(self):
        return download_dir() / self.filename

    def persist_state(self):
        return {"id": self.id, "url": self.url, "filename": self.filename,
                "size": self.size, "downloaded": self.downloaded,
                "status": self.status, "created": self.created}


class Manager:
    def __init__(self):
        self.jobs = {}
        self.lock = threading.Lock()
        self._load()

    # -- persistence ------------------------------------------------
    def _save(self):
        try:
            with self.lock:
                data = [j.persist_state() for j in self.jobs.values()]
            queue_path().write_text(json.dumps(data))
        except Exception:
            pass

    def _load(self):
        try:
            raw = queue_path().read_text()
        except Exception:
            return
        try:
            for d in json.loads(raw):
                j = Job(d["id"], d["url"], d["filename"], d.get("size"), True)
                j.downloaded = d.get("downloaded", 0)
                j.created = d.get("created", int(time.time()))
                # Incomplete jobs come back paused; recount real bytes on disk.
                if d.get("status") not in ("completed", "cancelled"):
                    j.status = "paused"
                    j.downloaded = self._recount(j)
                else:
                    j.status = d["status"]
                self.jobs[j.id] = j
        except Exception:
            pass

    def _recount(self, job):
        total = 0
        dd = download_dir()
        for i in range(NTHREADS):
            p = dd / (job.filename + ".p%d" % i)
            if p.exists():
                total += p.stat().st_size
        sp = dd / (job.filename + ".part")
        if sp.exists():
            total += sp.stat().st_size
        return total

    # -- lifecycle --------------------------------------------------
    def add(self, url, filename=""):
        url = (url or "").strip()
        if not (url.startswith("http://") or url.startswith("https://")):
            raise ValueError("Enter a valid http/https link")
        size, ranged, headers = probe(url)
        if not filename:
            filename = filename_from_url(url, headers)
        filename = sanitize_filename(filename)
        # avoid collisions
        base, ext = os.path.splitext(filename)
        n = 1
        while (download_dir() / filename).exists():
            n += 1
            filename = "%s (%d)%s" % (base, n, ext)
        jid = hashlib.md5((url + str(time.time())).encode()).hexdigest()[:12]
        job = Job(jid, url, filename, size, ranged and size is not None)
        with self.lock:
            self.jobs[jid] = job
        self._start(job)
        self._save()
        return job

    def _start(self, job):
        job.pause_flag = False
        job.stop_flag = False
        job.error = ""
        job.status = "downloading"
        job.threads = []
        if job.ranged and job.size:
            bounds = []
            part = job.size // NTHREADS
            for i in range(NTHREADS):
                s = i * part
                e = job.size - 1 if i == NTHREADS - 1 else (i + 1) * part - 1
                bounds.append((s, e))
            for i, (s, e) in enumerate(bounds):
                t = threading.Thread(target=self._worker_range,
                                     args=(job, i, s, e), daemon=True)
                job.threads.append(t)
                t.start()
        else:
            t = threading.Thread(target=self._worker_single, args=(job,), daemon=True)
            job.threads = [t]
            t.start()
        threading.Thread(target=self._watcher, args=(job,), daemon=True).start()

    def _worker_range(self, job, idx, start, end):
        ppath = job.part_path(idx)
        pos = start + (ppath.stat().st_size if ppath.exists() else 0)
        try:
            while pos <= end and not job.stop_flag and not job.pause_flag:
                hi = min(pos + CHUNK - 1, end)
                req = urllib.request.Request(
                    job.url, headers={**UA, "Range": "bytes=%d-%d" % (pos, hi)})
                with urllib.request.urlopen(req, timeout=30) as r:
                    if r.status not in (200, 206):
                        raise IOError("Server replied %s" % r.status)
                    # If server ignored Range and sent the full file, bail out.
                    if r.status == 200:
                        raise IOError("Range not honored")
                    with open(ppath, "ab") as f:
                        while not job.stop_flag and not job.pause_flag:
                            blk = r.read(65536)
                            if not blk:
                                break
                            f.write(blk)
                            job.add_bytes(len(blk))
                pos = hi + 1
        except Exception as e:
            with job.lock:
                if job.status == "downloading" and not job.pause_flag and not job.stop_flag:
                    job.status = "error"
                    job.error = str(e)[:200]

    def _worker_single(self, job):
        ppath = job.single_part_path()
        resume_from = ppath.stat().st_size if ppath.exists() else 0
        try:
            headers = dict(UA)
            if resume_from and job.size:
                headers["Range"] = "bytes=%d-" % resume_from
            req = urllib.request.Request(job.url, headers=headers)
            with urllib.request.urlopen(req, timeout=30) as r:
                if resume_from and r.status == 200:
                    # Server ignored our Range resume: restart the file cleanly.
                    resume_from = 0
                    open(ppath, "wb").close()
                with open(ppath, "ab" if resume_from else "wb") as f:
                    while not job.stop_flag and not job.pause_flag:
                        blk = r.read(65536)
                        if not blk:
                            break
                        f.write(blk)
                        job.add_bytes(len(blk))
            if job.size and ppath.stat().st_size >= job.size:
                self._finish_single(job)
            elif not job.size and not job.pause_flag and not job.stop_flag:
                # unknown size: EOF means done
                self._finish_single(job)
        except Exception as e:
            with job.lock:
                if job.status == "downloading" and not job.pause_flag and not job.stop_flag:
                    job.status = "error"
                    job.error = str(e)[:200]

    def _finish_single(self, job):
        with job.lock:
            if job.status != "downloading":
                return
            try:
                job.single_part_path().rename(job.final_path())
            except Exception:
                pass
            job.status = "completed"
        self._save()

    def _watcher(self, job):
        for t in job.threads:
            t.join()
        with job.lock:
            if job.stop_flag:
                job.status = "cancelled"
            elif job.pause_flag:
                job.status = "paused"
            elif job.status == "downloading":
                # Multi-thread path: if the server lied about Range support,
                # fall back to single-thread once, automatically.
                if (job.ranged and job.size and not job.range_retried
                        and "Range not honored" in (job.error or "")):
                    job.range_retried = True
                    job.ranged = False
                    job.downloaded = 0
                    self._cleanup_parts(job)
                    job.error = ""
                    self._start(job)
                else:
                    # merge parts if all present
                    if job.ranged and job.size:
                        if self._merge(job):
                            job.status = "completed"
                        elif job.status == "downloading":
                            job.status = "error"
                            if not job.error:
                                job.error = "Incomplete download"
                    # single-thread path already handled by _finish_single
            self._save()

    def _merge(self, job):
        parts = [job.part_path(i) for i in range(NTHREADS)]
        if not all(p.exists() for p in parts):
            return False
        if sum(p.stat().st_size for p in parts) < (job.size or 0):
            return False
        try:
            with open(job.final_path(), "wb") as out:
                for p in parts:
                    with open(p, "rb") as f:
                        while True:
                            blk = f.read(1024 * 256)
                            if not blk:
                                break
                            out.write(blk)
            for p in parts:
                p.unlink(missing_ok=True)
            return True
        except Exception as e:
            job.error = str(e)[:200]
            return False

    def _cleanup_parts(self, job):
        dd = download_dir()
        for i in range(NTHREADS):
            (dd / (job.filename + ".p%d" % i)).unlink(missing_ok=True)
        (dd / (job.filename + ".part")).unlink(missing_ok=True)

    # -- public ops -------------------------------------------------
    def get(self, jid):
        with self.lock:
            return self.jobs.get(jid)

    def pause(self, jid):
        job = self.get(jid)
        if not job:
            raise KeyError("job not found")
        job.pause_flag = True
        return job

    def resume(self, jid):
        job = self.get(jid)
        if not job:
            raise KeyError("job not found")
        if job.status in ("completed", "cancelled"):
            raise ValueError("Job is %s" % job.status)
        # recount real bytes in case files changed
        job.downloaded = self._recount(job)
        self._start(job)
        self._save()
        return job

    def cancel(self, jid):
        job = self.get(jid)
        if not job:
            raise KeyError("job not found")
        job.stop_flag = True
        job.pause_flag = False
        # wait for workers to exit before deleting parts (else they rewrite them)
        for t in job.threads:
            t.join(timeout=5)
        self._cleanup_parts(job)
        job.status = "cancelled"
        self._save()
        return job

    def delete(self, jid):
        with self.lock:
            job = self.jobs.pop(jid, None)
        if not job:
            raise KeyError("job not found")
        job.stop_flag = True
        self._cleanup_parts(job)
        try:
            job.final_path().unlink(missing_ok=True)
        except Exception:
            pass
        self._save()
        return True


manager = Manager()

# ---------------------------------------------------------------- routes
@app.route("/")
def index():
    return app.send_static_file("home.html")


@app.route("/api/version")
def version():
    return jsonify({"version": PIPELINE_VERSION, "app": APP_NAME})


@app.route("/api/jobs")
def jobs():
    with manager.lock:
        items = [j.to_dict() for j in manager.jobs.values()]
    items.sort(key=lambda x: x["created"], reverse=True)
    return jsonify(items)


@app.route("/api/job/<jid>")
def job_one(jid):
    job = manager.get(jid)
    if not job:
        return jsonify({"error": "job not found"}), 404
    return jsonify(job.to_dict())


@app.route("/api/add", methods=["POST"])
def add():
    data = request.get_json(force=True, silent=True) or {}
    try:
        job = manager.add(data.get("url", ""), data.get("filename", ""))
        return jsonify(job.to_dict())
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": "Could not start download: %s" % str(e)[:200]}), 500


@app.route("/api/pause/<jid>", methods=["POST"])
def pause(jid):
    try:
        return jsonify(manager.pause(jid).to_dict())
    except KeyError:
        return jsonify({"error": "job not found"}), 404


@app.route("/api/resume/<jid>", methods=["POST"])
def resume(jid):
    try:
        return jsonify(manager.resume(jid).to_dict())
    except KeyError:
        return jsonify({"error": "job not found"}), 404
    except ValueError as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/cancel/<jid>", methods=["POST"])
def cancel(jid):
    try:
        return jsonify(manager.cancel(jid).to_dict())
    except KeyError:
        return jsonify({"error": "job not found"}), 404


@app.route("/api/delete/<jid>", methods=["DELETE"])
def delete(jid):
    try:
        manager.delete(jid)
        return jsonify({"ok": True})
    except KeyError:
        return jsonify({"error": "job not found"}), 404


@app.route("/api/open/<jid>")
def open_file(jid):
    job = manager.get(jid)
    if not job or job.status != "completed":
        return jsonify({"error": "file not ready"}), 404
    p = job.final_path()
    if not p.exists():
        return jsonify({"error": "file missing"}), 404
    return send_file(str(p), as_attachment=True, download_name=job.filename)


# -- updater -------------------------------------------------------
_update_progress = {"done": 0, "total": 0, "running": False, "error": ""}


@app.route("/api/check-update")
def check_update():
    return jsonify(updater.check())


@app.route("/api/repo", methods=["GET", "POST"])
def repo():
    if request.method == "POST":
        data = request.get_json(force=True, silent=True) or {}
        r = (data.get("repo") or "").strip()
        if not r or "/" not in r or " " in r:
            return jsonify({"error": "Use format owner/repo"}), 400
        updater.set_repo(r)
    return jsonify({"repo": updater.get_repo()})


@app.route("/api/download-update", methods=["POST"])
def download_update():
    info = updater.check()
    if not info["update_available"] or not info["url"]:
        return jsonify({"error": info.get("error") or "No update available"}), 400
    if _update_progress["running"]:
        return jsonify({"error": "Download already running"}), 400

    def cb(done, total):
        _update_progress["done"] = done
        _update_progress["total"] = total

    def run():
        _update_progress.update(running=True, error="", done=0, total=0)
        try:
            dest = str(Path(download_dir()) / ("AZDownloader-Setup-v%s.exe" % info["latest"]))
            updater.download(info["url"], dest, cb)
            _update_progress["file"] = dest
            # launch installer
            os.startfile(dest) if hasattr(os, "startfile") else None
        except Exception as e:
            _update_progress["error"] = str(e)[:200]
        finally:
            _update_progress["running"] = False

    threading.Thread(target=run, daemon=True).start()
    return jsonify({"ok": True})


@app.route("/api/update-progress")
def update_progress():
    return jsonify(_update_progress)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8910, threaded=True)
