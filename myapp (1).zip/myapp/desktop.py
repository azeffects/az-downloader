"""PyWebView desktop wrapper: Flask runs in a background thread, the
native window shows the app. When the window closes the daemon thread
dies with the process."""
import threading

import webview

from app import app

PORT = 8910


def _run_flask():
    app.run(host="127.0.0.1", port=PORT, threaded=True, use_reloader=False)


if __name__ == "__main__":
    t = threading.Thread(target=_run_flask, daemon=True)
    t.start()
    webview.create_window("AZ Downloader", "http://127.0.0.1:%d" % PORT,
                          width=1100, height=720)
    webview.start()
